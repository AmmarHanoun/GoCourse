package main
import(
//  "booking/helper"
 // "booking/secondPa"
)

func main(){
 // creatMap1()
 // creatMap2()
//creatSliceOfMaps()
  //creatSliceOfMaps2()
 // helper.TestHelpPackage()
  //secondPa.Second()
 // forRange()
  //reserveUsingDoubleSlice()
  displayMap = map[string]map[string]map[uint]uint displayMap("1","London",10,10,displayMap)
  //doubleSlice()
 // switchCase()
}