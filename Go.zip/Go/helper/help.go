package helper
import(
  "fmt"
)
func TestHelpPackage(){
  fmt.Println("This is a test for helper package")
}

