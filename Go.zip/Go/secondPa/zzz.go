package secondPa
import "fmt"
func Second(){
  fmt.Println("This is the second package")
}